# JOHN SUPER AI BRAIN — Android starter project

This is the first real Android project for the Black & Blue app.

## What is included
- Android app shell (Java + WebView)
- Black & Blue home screen
- AI chat demo interface
- GitHub Actions workflow that builds a debug APK

## Important
This starter project is an installable-app foundation, not a finished AI service.
The chat currently demonstrates the interface and does not generate real AI answers.
A secure backend and an authorized AI API connection must be added before real AI chat.
Never put a private API key inside the Android app or upload it to GitHub.

## Build an APK using GitHub
1. Create a GitHub repository named `john-super-ai-brain`.
2. Upload all files and folders from this project to the repository root.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** and tap **Run workflow** (or push to `main`).
5. When the run finishes, open it and download the artifact named `JOHN-SUPER-AI-BRAIN-APK`.
6. Extract the ZIP artifact to get `app-debug.apk`, then install it on your Android phone.

The first build may take a few minutes.
